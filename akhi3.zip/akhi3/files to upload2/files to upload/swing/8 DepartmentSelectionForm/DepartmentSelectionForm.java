package handson8;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;

public class DepartmentSelectionForm extends JFrame {
    private JComboBox<String> departmentComboBox;

    public DepartmentSelectionForm() {
        setTitle("Department Selection");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        JLabel departmentLabel = new JLabel("Select Department:");
        departmentComboBox = new JComboBox<>();
        JButton showSelectionButton = new JButton("Show Selection");

        add(departmentLabel);
        add(departmentComboBox);
        add(showSelectionButton);

        // Load departments from the database
        loadDepartments();

        // Show selected department when the button is clicked
        showSelectionButton.addActionListener(e -> {
            String selectedDepartment = (String) departmentComboBox.getSelectedItem();
            JOptionPane.showMessageDialog(this, "Selected Department: " + selectedDepartment);
        });
    }

    private void loadDepartments() {
        // Clear the combo box
        departmentComboBox.removeAllItems();

        try (Connection conn = getConnection()) {
            String query = "SELECT name FROM departments";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            // Fetch department names and add them to the combo box
            while (rs.next()) {
                departmentComboBox.addItem(rs.getString("name"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading departments: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Connection getConnection() throws SQLException {
        // Update database URL, username, and password as needed
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/YourDatabaseName", "root", "0000");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DepartmentSelectionForm form = new DepartmentSelectionForm();
            form.setVisible(true);
        });
    }
}

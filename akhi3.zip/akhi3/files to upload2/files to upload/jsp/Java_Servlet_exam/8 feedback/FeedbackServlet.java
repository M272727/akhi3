package question8;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.*;

@WebServlet("/feedback")
public class FeedbackServlet extends HttpServlet {

    // POST method: insert feedback
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String message = request.getParameter("message");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/feedback_db", "root", "R150903@m");

            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO feedback (name, email, message) VALUES (?, ?, ?)");
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, message);

            stmt.executeUpdate();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        // redirect back to feedback page (which shows all feedbacks)
        response.sendRedirect("feedback");
    }

    // GET method: fetch all feedbacks and forward to JSP
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // We'll directly send ResultSet to JSP using attribute
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/feedback_db", "root", "R150903@m");

            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM feedback");

            // Store connection and resultset in request to use in JSP
            request.setAttribute("result", rs);
            request.setAttribute("connection", conn); // So we can close it in JSP

            RequestDispatcher rd = request.getRequestDispatcher("feedback.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

package question1;

// Required imports
import java.io.*;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")  // Servlet URL pattern (matches JSP form's action)
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * Default constructor
     */
    public RegisterServlet() {
        super();  // Calls parent constructor
    }

	/**
	 * Handles GET requests — not used in our form, but included by default
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Just returns some text in browser if accessed via GET
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * Handles POST requests — used when form is submitted
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// Set content type for HTML output
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		// Get data from JSP form using input "name" attributes
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String course = request.getParameter("course");
		String roll = request.getParameter("roll");

		// DB connection info — change if needed
		String url = "jdbc:mysql://localhost:3306/studentdb";
		String user = "root";
		String pass = "R150903@m";  // Put your MySQL password here if needed

		try {
			// Load the MySQL JDBC driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Connect to the database
			Connection conn = DriverManager.getConnection(url, user, pass);

			// SQL query to insert the data
			String sql = "INSERT INTO students (name, email, course, rollno) VALUES (?, ?, ?, ?)";
			PreparedStatement stmt = conn.prepareStatement(sql);

			// Set the ? placeholders with form data
			stmt.setString(1, name);
			stmt.setString(2, email);
			stmt.setString(3, course);
			stmt.setString(4, roll);

			// Execute the query
			int rows = stmt.executeUpdate();

			// Display result to user
			if (rows > 0) {
				out.println("<h2 style='color:green;'>✔ Student Registered Successfully!</h2>");
			} else {
				out.println("<h2 style='color:red;'>❌ Failed to register student.</h2>");
			}

			// Clean up
			stmt.close();
			conn.close();

		} catch (Exception e) {
			// Show any error that occurs
			out.println("<h3 style='color:red;'>Error: " + e.getMessage() + "</h3>");
			e.printStackTrace();
		}
	}
}

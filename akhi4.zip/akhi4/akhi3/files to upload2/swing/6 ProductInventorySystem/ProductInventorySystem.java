package handson6;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ProductInventorySystem extends JFrame {
    private JTextField idField, nameField, quantityField, priceField;
    private JComboBox<String> categoryComboBox;
    private JTable productTable;
    private DefaultTableModel tableModel;

    public ProductInventorySystem() {
        setTitle("Product Inventory System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 500);
        getContentPane().setLayout(null);

        JLabel lblId = new JLabel("Product ID:");
        lblId.setBounds(20, 20, 100, 25);
        getContentPane().add(lblId);

        idField = new JTextField();
        idField.setBounds(120, 20, 150, 25);
        getContentPane().add(idField);

        JLabel lblName = new JLabel("Product Name:");
        lblName.setBounds(20, 60, 100, 25);
        getContentPane().add(lblName);

        nameField = new JTextField();
        nameField.setBounds(120, 60, 150, 25);
        getContentPane().add(nameField);

        JLabel lblQuantity = new JLabel("Quantity:");
        lblQuantity.setBounds(20, 100, 100, 25);
        getContentPane().add(lblQuantity);

        quantityField = new JTextField();
        quantityField.setBounds(120, 100, 150, 25);
        getContentPane().add(quantityField);

        JLabel lblPrice = new JLabel("Price:");
        lblPrice.setBounds(20, 140, 100, 25);
        getContentPane().add(lblPrice);

        priceField = new JTextField();
        priceField.setBounds(120, 140, 150, 25);
        getContentPane().add(priceField);

        JLabel lblCategory = new JLabel("Category:");
        lblCategory.setBounds(20, 180, 100, 25);
        getContentPane().add(lblCategory);

        categoryComboBox = new JComboBox<>(new String[]{"Electronics", "Clothing", "Books", "Home & Kitchen", "Other"});
        categoryComboBox.setBounds(120, 180, 150, 25);
        getContentPane().add(categoryComboBox);

        JButton addButton = new JButton("Add");
        addButton.setBounds(20, 220, 100, 30);
        getContentPane().add(addButton);

        JButton updateButton = new JButton("Update");
        updateButton.setBounds(130, 220, 100, 30);
        getContentPane().add(updateButton);

        JButton deleteButton = new JButton("Delete");
        deleteButton.setBounds(240, 220, 100, 30);
        getContentPane().add(deleteButton);

        JButton refreshButton = new JButton("Refresh");
        refreshButton.setBounds(350, 220, 100, 30);
        getContentPane().add(refreshButton);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 260, 740, 180);
        getContentPane().add(scrollPane);

        productTable = new JTable();
        tableModel = new DefaultTableModel(new Object[]{"ID", "Name", "Quantity", "Price", "Category"}, 0);
        productTable.setModel(tableModel);
        scrollPane.setViewportView(productTable);

        // Button actions
        addButton.addActionListener(e -> addProduct());
        updateButton.addActionListener(e -> updateProduct());
        deleteButton.addActionListener(e -> deleteProduct());
        refreshButton.addActionListener(e -> loadProductData());

        // Load product data on startup
        loadProductData();
    }

    private void addProduct() {
        String id = idField.getText().trim();
        String name = nameField.getText().trim();
        String quantity = quantityField.getText().trim();
        String price = priceField.getText().trim();
        String category = categoryComboBox.getSelectedItem().toString();

        if (id.isEmpty() || name.isEmpty() || quantity.isEmpty() || price.isEmpty() || category.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = getConnection()) {
            String query = "INSERT INTO products (id, name, quantity, price, category) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, id);
            pstmt.setString(2, name);
            pstmt.setInt(3, Integer.parseInt(quantity));
            pstmt.setDouble(4, Double.parseDouble(price));
            pstmt.setString(5, category);
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Product added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            loadProductData();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error adding product: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateProduct() {
        // Similar logic to your sample for updating rows
    }

    private void deleteProduct() {
        // Similar logic to your sample for deleting rows
    }

    private void loadProductData() {
        tableModel.setRowCount(0);

        try (Connection conn = getConnection()) {
            String query = "SELECT * FROM products";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getString("id"),
                        rs.getString("name"),
                        rs.getInt("quantity"),
                        rs.getDouble("price"),
                        rs.getString("category")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading product data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/ProductInventory", "root", "0000");
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ProductInventorySystem frame = new ProductInventorySystem();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

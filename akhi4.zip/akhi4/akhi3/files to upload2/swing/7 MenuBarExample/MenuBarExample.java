package handson7;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuBarExample extends JFrame {
    public MenuBarExample() {
        setTitle("Menu Bar Example");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Create MenuBar
        JMenuBar menuBar = new JMenuBar();
        
        // Create File menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem newMenuItem = new JMenuItem("New");
        JMenuItem openMenuItem = new JMenuItem("Open");
        JMenuItem exitMenuItem = new JMenuItem("Exit");

        // Add action listeners for File menu items
        newMenuItem.addActionListener(e -> showMessage("New clicked"));
        openMenuItem.addActionListener(e -> showMessage("Open clicked"));
        exitMenuItem.addActionListener(e -> System.exit(0)); // Exit application

        // Add items to File menu
        fileMenu.add(newMenuItem);
        fileMenu.add(openMenuItem);
        fileMenu.addSeparator(); // Add separator between items
        fileMenu.add(exitMenuItem);

        // Create Edit menu
        JMenu editMenu = new JMenu("Edit");
        JMenuItem cutMenuItem = new JMenuItem("Cut");
        JMenuItem copyMenuItem = new JMenuItem("Copy");
        JMenuItem pasteMenuItem = new JMenuItem("Paste");

        // Add action listeners for Edit menu items
        cutMenuItem.addActionListener(e -> showMessage("Cut clicked"));
        copyMenuItem.addActionListener(e -> showMessage("Copy clicked"));
        pasteMenuItem.addActionListener(e -> showMessage("Paste clicked"));

        // Add items to Edit menu
        editMenu.add(cutMenuItem);
        editMenu.add(copyMenuItem);
        editMenu.add(pasteMenuItem);

        // Add menus to MenuBar
        menuBar.add(fileMenu);
        menuBar.add(editMenu);

        // Set the MenuBar to the frame
        setJMenuBar(menuBar);
    }

    private void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MenuBarExample frame = new MenuBarExample();
            frame.setVisible(true);
        });
    }
}
